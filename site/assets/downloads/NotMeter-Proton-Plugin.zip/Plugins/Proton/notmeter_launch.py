#!/usr/bin/env python3
"""Start NotMeter automatically after the Steam game has started."""

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time


def read(path, limit=262144):
    try:
        with path.open("rb") as stream:
            return stream.read(limit).decode("utf-8", errors="replace")
    except OSError:
        return ""


def process_state(proc, uid, appid, meter_name):
    games, meters = set(), set()
    for directory in proc.iterdir():
        if not directory.name.isdigit():
            continue
        comm = read(directory / "comm", 128).strip().lower()
        if comm not in {"aion2.exe", meter_name.lower()[:15]}:
            continue
        status = dict(line.split(":", 1) for line in read(directory / "status").splitlines() if ":" in line)
        if status.get("Uid", "").split()[:1] != [str(uid)]:
            continue
        if status.get("State", "").strip()[:1] in {"Z", "X"}:
            continue
        env = dict(item.split("=", 1) for item in read(directory / "environ").split("\0") if "=" in item)
        app_matches = any(env.get(key) == str(appid) for key in ("SteamAppId", "STEAM_APPID", "SteamGameId"))
        prefix = env.get("WINEPREFIX")
        compat = env.get("STEAM_COMPAT_DATA_PATH")
        prefix_matches = bool(prefix and Path(prefix).name == "pfx" and Path(prefix).parent.name == str(appid))
        prefix_matches |= bool(compat and Path(compat).name == str(appid))
        if not app_matches and not prefix_matches:
            continue
        # cmdline can contain AION2.exe while Proton is still waiting for wineserver.
        # Only an actual game process, with a stable PID/start time, is ready.
        fields = read(directory / "stat").rsplit(")", 1)[-1].split()
        if len(fields) < 20 or not fields[19].isdigit():
            continue
        identity = (int(directory.name), int(fields[19]))
        (games if comm == "aion2.exe" else meters).add(identity)
    return games, meters


def wait_for_game(probe, timeout=0, clock=time.monotonic, sleep=time.sleep, output=print):
    started = clock()
    seen = {}
    previous_message = None
    while True:
        games, meters = probe()
        now = clock()
        if games and meters:
            output("NotMeter is already running with AION 2. No second instance was started.", flush=True)
            return False
        seen = {key: seen.get(key, now) for key in games}
        if any(now - since >= 2 for since in seen.values()):
            return True
        if timeout and now - started >= timeout:
            raise TimeoutError("AION 2 did not become ready. NotMeter was not started; no game processes were changed.")
        message = (
            "Close the NotMeter instance opened with the old command, then start AION 2 in Steam. "
            "This launcher will wait and reopen NotMeter automatically."
            if meters else
            "Waiting for AION 2. You can click Play in Steam now; NotMeter will open automatically after the game starts."
        )
        if message != previous_message:
            output(message, flush=True)
            previous_message = message
        sleep(0.5)


def check_capture(executable):
    plugin = executable.parent / "Plugins" / "Proton"
    if not (plugin / "NotMeter.Capture.Proton.dll").is_file():
        raise ValueError("Extract the Proton plugin ZIP next to NotMeter.exe first.")
    try:
        with (plugin / "connection.json").open("rb") as stream:
            data = stream.read(2049)
        connection = json.loads(data) if len(data) <= 2048 else {}
        if not isinstance(connection, dict) or connection.get("version") != 1:
            raise ValueError()
    except (OSError, ValueError):
        raise ValueError("Start notmeter_capture.py in another terminal before launching NotMeter.") from None


def launch(executable, appid, protontricks, timeout=0, probe=None):
    check_capture(executable)
    probe = probe or (lambda: process_state(Path("/proc"), os.getuid(), appid, executable.name))
    if not wait_for_game(probe, timeout):
        return 0
    check_capture(executable)
    env = os.environ.copy()
    env["NOTMETER_PROTON_CAPTURE"] = "1"
    print("AION 2 is running. Starting NotMeter in your existing Proton environment.", flush=True)
    # No Wine/Proton process is created until the game passes waitforexitandrun.
    return subprocess.call([protontricks, "--appid", str(appid), str(executable)], env=env)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exe", type=Path, default=Path(__file__).resolve().parents[2] / "NotMeter.exe",
                        help="NotMeter.exe path; defaults to the folder containing Plugins/Proton.")
    parser.add_argument("--appid", type=int, default=3393110, help="AION 2 Steam app ID (default: 3393110).")
    parser.add_argument("--timeout", type=int, default=0, help="Seconds to wait; 0 waits until the game starts or Ctrl+C.")
    args = parser.parse_args()
    if sys.platform != "linux":
        parser.error("Run this script on the Linux host, outside Proton.")
    if os.geteuid() == 0:
        parser.error("Run as your normal desktop user, without sudo.")
    if args.appid <= 0 or args.timeout < 0:
        parser.error("--appid must be positive and --timeout must be zero or positive.")
    executable = args.exe.expanduser().resolve()
    if not executable.is_file() or executable.suffix.lower() != ".exe":
        parser.error("NotMeter.exe was not found. Use --exe followed by its full path.")
    protontricks = shutil.which("protontricks-launch")
    if not protontricks:
        parser.error("Native protontricks-launch was not found. Use the native Protontricks installation that runs NotMeter.")
    try:
        return launch(executable, args.appid, protontricks, args.timeout)
    except (OSError, ValueError, TimeoutError) as error:
        print(f"NotMeter was not launched: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nLauncher stopped. Steam and AION 2 were not stopped.", file=sys.stderr)
        sys.exit(130)
