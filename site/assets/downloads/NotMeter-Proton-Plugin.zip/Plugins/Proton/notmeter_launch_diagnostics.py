#!/usr/bin/env python3
"""Read-only Linux process snapshots for a Proton launch-order report."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys


KNOWN = {"aion2.exe", "notmeter.exe", "wineserver", "wine", "wine64",
         "wine-preloader", "wine64-preloader", "proton", "steam", "steam.exe",
         "bwrap", "pressure-vessel", "pv-bwrap", "pressure-vessel-wrap",
         "steam-runtime-launcher-service", "steam-runtime-launcher-interface-0",
         "_v2-entry-point", "protontricks", "protontricks-launch"}


def read(path, limit=262144):
    try:
        with path.open("rb") as stream:
            return stream.read(limit).decode("utf-8", errors="replace")
    except OSError:
        return ""


def name(value):
    return value.replace("\\", "/").rsplit("/", 1)[-1].lower()


def snapshot(proc, uid, prefixes):
    processes = []
    unreadable = 0
    for directory in sorted(proc.iterdir(), key=lambda entry: entry.name):
        if not directory.name.isdigit():
            continue
        status = dict(line.split(":", 1) for line in read(directory / "status").splitlines() if ":" in line)
        if status.get("Uid", "").split()[:1] != [str(uid)]:
            continue
        args = read(directory / "cmdline").split("\0")
        identities = sorted({name(arg) for arg in args if name(arg) in KNOWN})
        comm = name(read(directory / "comm").strip())
        if comm in KNOWN:
            identities = sorted(set(identities) | {comm})
        if not identities:
            continue
        environment = read(directory / "environ")
        if not environment:
            unreadable += 1
        env = dict(item.split("=", 1) for item in environment.split("\0") if "=" in item)
        prefix = env.get("WINEPREFIX") or (env.get("STEAM_COMPAT_DATA_PATH", "").rstrip("/") + "/pfx" if env.get("STEAM_COMPAT_DATA_PATH") else "")
        prefix_id = "unknown"
        if prefix:
            key = str(Path(prefix).resolve())
            prefix_id = prefixes.setdefault(key, f"prefix-{len(prefixes) + 1}")
        verbs = sorted({arg for index, arg in enumerate(args) if index > 0 and name(args[index - 1]) == "proton"
                        and arg in {"run", "waitforexitandrun", "runinprefix"}})
        wait_channel = read(directory / "wchan").strip()
        process_state = status.get("State", "?").strip()[:1]
        processes.append({
            "pid": int(directory.name),
            "parent": int(status.get("PPid", "0").strip() or "0"),
            "process": comm if comm in KNOWN else "launcher",
            "names": identities,
            "state": process_state if process_state in "RSDZTtXxKWPI" else "?",
            "wait": wait_channel if re.fullmatch(r"[A-Za-z0-9_]{1,80}", wait_channel) else "unavailable",
            "prefix": prefix_id,
            "aion2_app": any(env.get(key) == "3393110" for key in ("SteamAppId", "STEAM_APPID", "SteamGameId")),
            "proton_verb": verbs,
            "wineserver_wait": any(name(arg) == "wineserver" and "-w" in args[index + 1:]
                                   for index, arg in enumerate(args)),
        })
    pids = {process["pid"] for process in processes}
    locks = []
    for line in read(proc / "locks", 1048576).splitlines():
        fields = line.split()
        waiting = len(fields) > 1 and fields[1] == "->"
        offset = 1 if waiting else 0
        if len(fields) > 5 + offset and fields[4 + offset].isdigit() and int(fields[4 + offset]) in pids:
            locks.append({"pid": int(fields[4 + offset]), "waiting": waiting})
    return {"time": datetime.now(timezone.utc).isoformat(), "processes": processes,
            "process_locks": locks, "unreadable_environments": unreadable}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--snapshot", action="store_true", help="Print one snapshot without prompts.")
    args = parser.parse_args()
    if sys.platform != "linux":
        parser.error("Run this script on the Linux host, outside Proton, without sudo.")
    if os.geteuid() == 0:
        parser.error("Run as your normal desktop user, without sudo.")
    prefixes = {}
    session = os.environ.get("XDG_SESSION_TYPE", "unknown")
    report = {"format": "NotMeter launch diagnostics v1",
              "session": session if session in {"x11", "wayland", "tty"} else "unknown", "snapshots": []}
    if args.snapshot:
        report["snapshots"].append(snapshot(Path("/proc"), os.getuid(), prefixes))
    else:
        print("This reads process status only. It does not launch or stop programs, change settings, or capture packets.")
        steps = [
            ("before", "Close AION 2 and NotMeter normally, leave Steam open, then press Enter."),
            ("meter-first", "Start NotMeter using your usual command. Once its window appears, press Enter."),
            ("game-requested", "Click Play for AION 2 in Steam. Wait about 20 seconds, then press Enter."),
            ("meter-closed", "Close only NotMeter normally. Wait about 10 seconds, then press Enter."),
            ("game-retried", "With NotMeter closed, launch AION 2 again in Steam. Wait about 20 seconds, then press Enter."),
        ]
        for stage, prompt in steps:
            input(prompt + "\n")
            entry = snapshot(Path("/proc"), os.getuid(), prefixes)
            entry["stage"] = stage
            report["snapshots"].append(entry)
    print("\n--- Copy from here ---")
    print(json.dumps(report, indent=2))
    print("--- End of report ---")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print("\nCancelled; no programs or settings were changed.", file=sys.stderr)
        sys.exit(1)
