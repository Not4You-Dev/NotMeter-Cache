#!/usr/bin/env python3
"""Optional Linux-only, read-only capture bridge for NotMeter under Proton."""

import argparse
import hmac
import ipaddress
import json
import os
from pathlib import Path
import secrets
import select
import shutil
import socket
import stat
import subprocess
import sys
import tempfile


MAGIC = b"NMPCAP1\n"


def read_exact(connection, length):
    result = bytearray()
    while len(result) < length:
        chunk = connection.recv(length - len(result))
        if not chunk:
            raise ConnectionError("Connection closed during authentication.")
        result.extend(chunk)
    return bytes(result)


def authenticate(connection, key):
    connection.settimeout(5)
    if read_exact(connection, len(MAGIC)) != MAGIC:
        raise ValueError("Unsupported client.")
    client_nonce = read_exact(connection, 32)
    server_nonce = secrets.token_bytes(32)
    proof = hmac.digest(key, b"server:" + client_nonce, "sha256")
    connection.sendall(proof + server_nonce)
    if not hmac.compare_digest(read_exact(connection, 32),
                               hmac.digest(key, b"client:" + server_nonce, "sha256")):
        raise ValueError("Client authentication failed.")


def capture_command(dumpcap, interface, address, game_port):
    address = ipaddress.IPv4Address(address)
    if address.is_unspecified or address.is_loopback or address.is_multicast or int(address) == 0xffffffff:
        raise ValueError("Select the IPv4 address of the game network interface.")
    if not 1 <= game_port <= 65535:
        raise ValueError("Invalid game port.")
    return [str(dumpcap), "-i", interface, "-p", "-P", "-q", "-s", "262144",
            "-B", "8", "--update-interval", "100", "-f",
            f"tcp and host {address} and port {game_port}", "-w", "-"]


def system_dumpcap():
    found = shutil.which("dumpcap")
    if not found:
        raise RuntimeError("Install dumpcap from your Linux distribution's official repository first.")
    path = Path(found).resolve(strict=True)
    info = path.stat()
    if info.st_uid != 0 or info.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
        raise RuntimeError("Use the distribution-provided, root-owned dumpcap executable.")
    return path


def interface_address(interface):
    import fcntl
    if interface not in dict((name, index) for index, name in socket.if_nameindex()) or interface == "lo":
        raise ValueError("Select one local game network interface, not a pipe, URL, or 'any'.")
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        result = fcntl.ioctl(sock.fileno(), 0x8915, interface.encode()[:15].ljust(256, b"\0"))
    return socket.inet_ntoa(result[20:24])


def write_connection(directory, port, key, address, game_port):
    fd, temporary = tempfile.mkstemp(prefix=".connection-", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as output:
            json.dump(dict(version=1, port=port, token=key.hex(), clientAddress=address, gamePort=game_port), output)
        os.replace(temporary, directory / "connection.json")
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def stream_capture(connection, command):
    capture = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, shell=False)
    try:
        while True:
            ready, _, _ = select.select([capture.stdout, connection], [], [], 1)
            if connection in ready:
                # The capture protocol has no client commands after authentication.
                return
            if capture.stdout in ready:
                data = capture.stdout.read1(65536)
                if not data:
                    raise RuntimeError("dumpcap stopped. Check its message above and your capture permissions.")
                connection.sendall(data)
    finally:
        if capture.poll() is None:
            capture.terminate()
            try:
                capture.wait(timeout=3)
            except subprocess.TimeoutExpired:
                capture.kill()
                capture.wait(timeout=3)
        capture.stdout.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--interface", required=True, help="Local interface carrying the game connection, e.g. enp3s0")
    parser.add_argument("--plugin-dir", type=Path, required=True, help="Plugins/Proton next to NotMeter.exe")
    parser.add_argument("--game-port", type=int, default=13328)
    args = parser.parse_args()
    if not sys.platform.startswith("linux"):
        parser.error("Run this helper on the Linux host, not inside Proton.")
    if os.geteuid() == 0:
        parser.error("Run as your regular desktop user. Do not run Proton or this helper with sudo.")

    import fcntl
    directory = args.plugin_dir.resolve(strict=True)
    if not (directory / "NotMeter.Capture.Proton.dll").is_file():
        parser.error("The selected directory does not contain the Proton plugin.")
    address = interface_address(args.interface)
    command = capture_command(system_dumpcap(), args.interface, address, args.game_port)
    lock_fd = os.open(directory / ".capture.lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    key = secrets.token_bytes(32)
    published = False
    try:
        info = os.fstat(lock_fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise RuntimeError("The capture lock must be a private file owned by your user.")
        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server:
            server.bind(("127.0.0.1", 0))
            server.listen(1)
            write_connection(directory, server.getsockname()[1], key, address, args.game_port)
            published = True
            print(f"Ready: {args.interface}, game port {args.game_port}. Start NotMeter with NOTMETER_PROTON_CAPTURE=1.", flush=True)
            while True:
                connection, _ = server.accept()
                with connection:
                    try:
                        authenticate(connection, key)
                    except (ValueError, ConnectionError, OSError):
                        continue
                    print("NotMeter connected. Capturing game traffic locally; no capture file is written.", flush=True)
                    stream_capture(connection, command)
                    break
    finally:
        if published:
            (directory / "connection.json").unlink(missing_ok=True)
        os.close(lock_fd)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except (OSError, ValueError, RuntimeError) as error:
        print(f"Capture helper: {error}", file=sys.stderr)
        sys.exit(1)
