#!/usr/bin/env python3
"""Start the Linux capture helper and NotMeter together with one command."""

import argparse
from contextlib import contextmanager
import os
from pathlib import Path
import shutil
import signal
import socket
import stat
import subprocess
import sys
import threading
import time

import notmeter_capture as capture
import notmeter_launch as launcher


def available_interfaces():
    result = {}
    for _, name in socket.if_nameindex():
        try:
            address = capture.interface_address(name)
            capture.capture_command("dumpcap", name, address, 13328)
            result[name] = address
        except (OSError, ValueError):
            continue
    return result


def choose_interface(interfaces, requested, saved, interactive, ask=input):
    if requested:
        if requested not in interfaces:
            raise ValueError("The selected interface has no usable local IPv4 address. Check: ip -br -4 address")
        return requested
    if saved in interfaces:
        return saved
    if len(interfaces) == 1:
        return next(iter(interfaces))
    if not interfaces:
        raise ValueError("No local IPv4 capture interface was found. Connect to the game network first.")
    if not interactive:
        raise ValueError("Several network interfaces are available. Run once in a terminal or use --interface NAME.")
    names = list(interfaces)
    print("Choose the interface carrying the game connection (saved for next time):", flush=True)
    for index, name in enumerate(names, 1):
        print(f"  {index}. {name} ({interfaces[name]})", flush=True)
    while True:
        choice = ask("Interface number: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(names):
            return names[int(choice) - 1]
        print("Enter one of the interface numbers above.", flush=True)


@contextmanager
def session_lock(directory):
    import fcntl
    fd = os.open(directory / ".start.lock", os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o077:
            raise RuntimeError("The launcher lock must be a private file owned by your user.")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("This NotMeter launcher is already running. Use its existing terminal.") from None
        yield
    finally:
        os.close(fd)


def remember_interface(directory, interface):
    fd = os.open(directory / ".start-interface", os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as output:
        output.write(interface + "\n")


def stop_helper(helper):
    if helper.poll() is not None:
        return
    # Only the helper and its dumpcap child belong to this new process group.
    try:
        os.killpg(helper.pid, signal.SIGINT)
    except ProcessLookupError:
        return
    try:
        helper.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(helper.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        helper.wait(timeout=5)


def run_session(executable, interface, appid, protontricks, timeout=0, probe=None):
    directory = executable.parent / "Plugins" / "Proton"
    probe = probe or (lambda: launcher.process_state(Path("/proc"), os.getuid(), appid, executable.name))
    if not launcher.wait_for_game(probe, timeout):
        return 0
    ready = threading.Event()
    helper = subprocess.Popen(
        [sys.executable, "-u", str(directory / "notmeter_capture.py"),
         "--interface", interface, "--plugin-dir", str(directory)],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True, encoding="utf-8", errors="replace", start_new_session=True)

    def relay():
        for line in helper.stdout:
            print(line.rstrip(), flush=True)
            if line.startswith("Ready: "):
                ready.set()

    reader = threading.Thread(target=relay, daemon=True)
    reader.start()
    try:
        deadline = time.monotonic() + 15
        while not ready.wait(0.1):
            if helper.poll() is not None:
                raise RuntimeError("The capture helper could not start. Check its message above; NotMeter was not started.")
            if time.monotonic() >= deadline:
                raise TimeoutError("The capture helper did not become ready within 15 seconds.")
        if helper.poll() is not None:
            raise RuntimeError("The capture helper stopped before NotMeter could start.")
        remember_interface(directory, interface)
        print("Capture is ready. Keep this terminal open while using NotMeter. Ctrl+C stops capture.", flush=True)
        games, meters = probe()
        if meters:
            print("NotMeter is already running. No second instance was started.", flush=True)
            return 0
        if not games:
            raise RuntimeError("AION 2 exited before NotMeter could start. Start the game and run this command again.")
        launcher.check_capture(executable)
        env = os.environ.copy()
        env["NOTMETER_PROTON_CAPTURE"] = "1"
        # Keep terminal cancellation away from Proton and the shared game prefix.
        meter = subprocess.Popen([protontricks, "--appid", str(appid), str(executable)],
                                 env=env, start_new_session=True)
        while True:
            code = meter.poll()
            if code is not None:
                return code
            code = helper.poll()
            if code is not None:
                if code != 0:
                    raise RuntimeError("Capture stopped unexpectedly. Check the message above, close NotMeter and try again.")
                return 0
            time.sleep(0.2)
    finally:
        stop_helper(helper)
        reader.join(timeout=2)
        if not reader.is_alive():
            helper.stdout.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--exe", type=Path, default=Path(__file__).resolve().parents[2] / "NotMeter.exe")
    parser.add_argument("--interface", help="Game network interface; overrides the saved selection.")
    parser.add_argument("--appid", type=int, default=3393110)
    parser.add_argument("--timeout", type=int, default=0, help="Seconds to wait for AION 2; 0 waits until Ctrl+C.")
    args = parser.parse_args()
    if sys.platform != "linux":
        parser.error("Run this script on the Linux host, outside Proton.")
    if os.geteuid() == 0:
        parser.error("Run as your normal desktop user, without sudo.")
    if args.appid <= 0 or args.timeout < 0:
        parser.error("--appid must be positive and --timeout must be zero or positive.")
    executable = args.exe.expanduser().resolve()
    directory = executable.parent / "Plugins" / "Proton"
    if not executable.is_file() or executable.suffix.lower() != ".exe":
        parser.error("NotMeter.exe was not found. Use --exe followed by its full path.")
    required = ["NotMeter.Capture.Proton.dll", "notmeter_capture.py", "notmeter_launch.py"]
    if any(not (directory / name).is_file() for name in required):
        parser.error("Extract the complete Proton plugin ZIP next to NotMeter.exe first.")
    protontricks = shutil.which("protontricks-launch")
    if not protontricks:
        parser.error("Native protontricks-launch was not found. Install native Protontricks first.")
    try:
        capture.system_dumpcap()
        with session_lock(directory):
            saved = launcher.read(directory / ".start-interface", 64).strip()
            interface = choose_interface(available_interfaces(), args.interface, saved, sys.stdin.isatty())
            print(f"Game capture interface: {interface}. Use --interface NAME to change it.", flush=True)
            return run_session(executable, interface, args.appid, protontricks, args.timeout)
    except (OSError, ValueError, RuntimeError, TimeoutError, EOFError) as error:
        print(f"NotMeter startup: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\nCapture stopped. Close NotMeter normally before starting again. Steam and AION 2 were not stopped.", file=sys.stderr)
        sys.exit(130)
