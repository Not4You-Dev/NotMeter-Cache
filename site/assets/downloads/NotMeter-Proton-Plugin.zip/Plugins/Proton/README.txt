NotMeter Proton capture plugin - EXPERIMENTAL
===========================================

This optional plugin keeps the NotMeter UI under Proton and uses your Linux
distribution's dumpcap to capture game traffic. It contains no Windows capture
driver, DLL injection, packet injection, automatic installer, or security-setting
changes. False-positive-free antivirus detection cannot be guaranteed.

This requires a NotMeter build that includes the Proton plugin loader.
The previously built 1.0.254 EXE does not include it. A plugin ZIP alone cannot
add the loader to an older EXE. Linux/Proton live-game validation is still required.

Requirements
------------
- An existing Proton setup that can already run NotMeter's UI.
- Linux x86-64, Python 3.9+, and dumpcap from your distribution's official repository.
- Your regular user must already be allowed to capture with dumpcap. Follow your
  distribution's Wireshark capture-permission documentation if it is denied.
  This helper does not install packages, run sudo, change capabilities, grant
  permissions, disable antivirus, or alter the firewall.
- One local interface with IPv4 carrying the game connection. The default game
  server port is 13328. VPN/accelerator tunnels may hide the original game traffic;
  select the interface on which the original TCP game connection is visible.

Quick start (one terminal)
--------------------------
1. Extract this ZIP next to NotMeter.exe. Keep the Plugins/Proton directory layout.
2. Prepare native Protontricks, Python 3.9+ and dumpcap as described above.
   Run 'dumpcap -D' as your normal user to check capture access.
3. Run this on the Linux host, without sudo:

   python3 "/path/to/NotMeter/Plugins/Proton/notmeter_start.py"

   Replace the path with your installation path. If several local IPv4 interfaces
   are available, select the one carrying game traffic. The selection is saved
   after capture starts, so the same command works next time without selecting it
   again. Use --interface enp3s0 to change it. A VPN/accelerator may require a
   different interface; select one where the original game connection is visible.
4. Click Play for AION 2 in Steam if it is not already running. The script waits
   for the actual game process, starts the capture helper, then opens NotMeter
   automatically in your existing Proton environment. Keep this terminal open.
   You do not need to run notmeter_capture.py or notmeter_launch.py separately.
5. Closing NotMeter stops the helper started by this script. Ctrl+C cancels a
   pending start or stops this script's capture helper; it does not forcibly close
   NotMeter, Steam or the game. Close NotMeter normally before running it again.

The default Steam app ID is 3393110. Use --appid NUMBER for another Steam
installation, --exe "/path/to/NotMeter.exe" for another meter location and
--timeout SECONDS to limit the game wait. The script prevents duplicate starts
from the same plugin folder. Existing manually started capture helpers are not
stopped or replaced; close their terminal normally before using quick start.
No packages, game files, Proton prefixes or capture permissions are changed.
This automation is covered by launcher tests; Linux live-game validation is still
required. It does not remove the existing Proton limitations listed below.

Manual setup (two terminals, still supported)
--------------------------------------------
1. Extract this ZIP next to NotMeter.exe. Keep the Plugins/Proton directory layout.
2. Identify the game interface using 'ip -br -4 address' on Linux. Do not select
   'any', a remote capture URL, a pipe, or the loopback interface.
3. Run on the Linux host, as your normal desktop user:

   python3 "/path/to/NotMeter/Plugins/Proton/notmeter_capture.py" \
     --interface enp3s0 --plugin-dir "/path/to/NotMeter/Plugins/Proton"

   Replace both the path and interface. Leave the terminal open.
4. In a second Linux terminal, use the new launcher instead of directly running
   protontricks-launch with the game's app ID:

   python3 "/path/to/NotMeter/Plugins/Proton/notmeter_launch.py"

   You can run this command before or after clicking Play for AION 2 in Steam.
   If the game is not running, the launcher waits without starting Wine or NotMeter.
   Once the actual game process starts, the meter window opens automatically.
   Leave the launcher terminal open; Ctrl+C cancels a pending launch.
   The Steam Global app ID defaults to 3393110. Use --appid NUMBER for another
   Steam installation, and --exe "/path/to/NotMeter.exe" for a different EXE path.

   This uses your existing native Protontricks and the same working Proton version,
   prefix and saved settings. No game files or Steam settings are changed.
   Keep the helper and Proton on the host's loopback network. Flatpak/network-
   isolated launchers need separate validation; do not expose the bridge port.
5. Enter the game world after NotMeter opens. While opted in, the plugin uses
   the Linux helper instead of the saved Npcap/WinDivert selection. Settings are not
   changed. The meter window title/status identifies Proton when connected.
6. Confirm character detection and damage tracking. UI rendering, overlay focus,
   process detection and FPS features may have additional Proton limitations.

CachyOS preparation
-------------------
The reported environment is CachyOS, AION 2 through Steam with
proton-cachyos-11.0-20260703, and NotMeter launched through Protontricks.
This is a test target, not a verified compatibility claim.
Arch's official wireshark-cli package supplies /usr/bin/dumpcap. Check the available
package in your configured distribution repository and follow its capture-permission
instructions. Run 'dumpcap -D' as your normal user to check interface access first.
Flatpak Protontricks needs its own environment/file-access configuration; the native
command above is not a Flatpak instruction. Do not turn off sandboxing to guess a fix.

Why the launcher waits
----------------------
The reported log shows the game launcher waiting in 'wineserver -w' while NotMeter
keeps the game's Proton prefix alive. A command line containing AION2.exe is not
enough to prove the game is running. The new launcher waits for the actual game
process, owned by your user and matching the Steam app, before starting NotMeter.
It does not keep a Wine process open while waiting, kill wineserver, recreate a
prefix, move your settings or change your Proton version.

Close any NotMeter instance opened using the old command once before switching to
this launcher. If you exit AION 2 and want to restart it, close NotMeter normally
and restart the helper/launcher as well. The launcher does not forcibly close an
already running meter or game. It automates initial launch order; it does not make
the old shared-prefix command safe to run before the game.

Stopping / reverting
--------------------
Close NotMeter, then stop the helper with Ctrl+C. The helper removes its private
connection.json. Remove NOTMETER_PROTON_CAPTURE=1 to use the previous capture mode.
Windows users do not need this plugin, and normal Windows ignores this opt-in.
The helper intentionally ends when NotMeter disconnects. To reconnect, restart
the helper first and then NotMeter; it never silently falls back to another driver.

Data handling
-------------
Only the selected local IPv4 address and game TCP port are captured, with
promiscuous mode disabled. Capture data streams in memory over 127.0.0.1 only.
Each helper run generates a fresh secret in an owner-only connection file;
both sides authenticate before capture starts. Do not share connection.json.
No packet payloads or authentication secrets are logged by this plugin/helper.
NotMeter's normal game-data processing and configured online features still apply.

Troubleshooting logs
--------------------
Diagnostic file logging is off by default, including under Wine/Proton.
NOTMETER_PROTON_CAPTURE=1 enables capture only; it does not enable logging.
If troubleshooting is needed, close NotMeter and restart the helper, then launch:

env NOTMETER_PROTON_DIAGNOSTICS=1 python3 "$HOME/NotMeter/Plugins/Proton/notmeter_launch.py"

For quick start, use the same environment variable with notmeter_start.py instead.

Keep AION 2 running. Use your existing Python command and dumpcap installation.
This explicit diagnostic mode writes NotMeter-Proton-diagnostics.log beside the EXE.
It records a status snapshot every 5 seconds, including when no traffic arrives.
Each file is limited to 1 MiB;
the previous file is retained as NotMeter-Proton-diagnostics.log.previous.
If the EXE folder is not writable, the fallback is LocalApplicationData/NotMeter/
Diagnostics inside the same Proton prefix.
The log contains build IDs, capture stages/counters, process lookup failure codes,
Steam verification results and character detection success/failure. It does not
contain packet payloads, character names, IP addresses or authentication secrets.
For a detection problem, stay in the game and move or attack for about 30 seconds,
then share the log and its .previous file if present. Never share connection.json.
To stop logging, close NotMeter and restart it with the normal launch command
without NOTMETER_PROTON_DIAGNOSTICS=1. Existing diagnostic files are left unchanged.

Launch-order diagnostics
------------------------
If AION 2 will not start when NotMeter was started first, run this on the Linux
host, without sudo, and follow the five prompts:

python3 "/path/to/NotMeter/Plugins/Proton/notmeter_launch_diagnostics.py"

Copy the report between the markers. This optional tool only reads process state;
it does not start/stop programs or change Steam, Proton, prefixes or game settings.
It records process IDs, known executable names, wait states and anonymous prefix
groups. It does not print full command lines, environment variables, usernames,
paths, tokens or packet data, and does not automatically create a log file.
--snapshot prints one snapshot without prompts. This helps distinguish a Proton
wait, a retained wineserver or an exited launcher; it is not a launch-order fix.

Source / references
-------------------
The Python helper is readable source, not a packed executable. The managed plugin
is built without obfuscation. plugin.json detects DLL damage/mismatch; it is not a
publisher signature. Obtain the ZIP from the official NotMeter distribution only.
dumpcap itself is not bundled:
https://www.wireshark.org/docs/man-pages/dumpcap.html
https://wiki.wireshark.org/CaptureSetup/CapturePrivileges
https://github.com/Matoking/protontricks#usage
https://archlinux.org/packages/extra/x86_64/wireshark-cli/files/
